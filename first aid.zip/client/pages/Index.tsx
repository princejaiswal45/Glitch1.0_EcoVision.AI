import { useMemo, useState } from "react";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { INJURY_GUIDES } from "@/data/injuries";
import { Link } from "react-router-dom";

export default function Index() {
  const [query, setQuery] = useState("");

  const results = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return INJURY_GUIDES;
    return INJURY_GUIDES.filter(
      (g) => g.title.toLowerCase().includes(q) || g.summary.toLowerCase().includes(q),
    );
  }, [query]);

  return (
    <div>
      <section className="grid gap-8 md:grid-cols-2 items-center">
        <div>
          <h1 className="text-4xl md:text-5xl font-extrabold tracking-tight">
            First aid, fast. Offline.
          </h1>
          <p className="mt-3 text-lg text-muted-foreground">
            Quick, reliable, step-by-step guidance for emergencies. Works even without internet.
          </p>
          <div className="mt-6 flex items-center gap-3">
            <Badge className="bg-emerald-600 text-white">Offline-first</Badge>
            <Badge variant="secondary">No sign-in</Badge>
            <Badge variant="secondary">Free</Badge>
          </div>
          <div className="mt-6 max-w-md">
            <Input
              aria-label="Search guides"
              placeholder="Search: burns, cuts, fractures, choking, bleeding..."
              value={query}
              onChange={(e) => setQuery(e.target.value)}
            />
          </div>
        </div>
        <div className="relative">
          <div className="absolute -inset-6 rounded-3xl bg-primary/10 blur-2xl" aria-hidden />
          <div className="relative rounded-3xl border bg-card p-6">
            <h2 className="font-semibold">How it works</h2>
            <Separator className="my-3" />
            <ol className="space-y-3 text-sm">
              <li className="flex items-start gap-3"><span className="mt-0.5 inline-flex h-6 w-6 items-center justify-center rounded-full bg-primary text-primary-foreground text-xs font-bold">1</span>Open a guide.</li>
              <li className="flex items-start gap-3"><span className="mt-0.5 inline-flex h-6 w-6 items-center justify-center rounded-full bg-primary text-primary-foreground text-xs font-bold">2</span>Follow the steps calmly.</li>
              <li className="flex items-start gap-3"><span className="mt-0.5 inline-flex h-6 w-6 items-center justify-center rounded-full bg-primary text-primary-foreground text-xs font-bold">3</span>App stays available offline.</li>
            </ol>
            <p className="mt-4 text-xs text-muted-foreground">Educational content only. Call emergency services if in doubt.</p>
          </div>
        </div>
      </section>

      <section id="guides" className="mt-12">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-semibold">Guides</h2>
          <span className="text-sm text-muted-foreground">{results.length} available</span>
        </div>

        <div className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {results.map((g) => (
            <Card key={g.slug} className="group hover:shadow-lg transition-shadow">
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span>{g.title}</span>
                  <Badge variant="secondary">Step-by-step</Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground min-h-[48px]">{g.summary}</p>
                <div className="mt-4 flex items-center justify-between">
                  <div className="flex -space-x-2 overflow-hidden" aria-hidden>
                    {g.steps.slice(0, 3).map((_, i) => (
                      <span key={i} className="inline-flex h-7 w-7 items-center justify-center rounded-full bg-primary/10 text-xs text-primary border">
                        {i + 1}
                      </span>
                    ))}
                    {g.steps.length > 3 && (
                      <span className="inline-flex h-7 w-7 items-center justify-center rounded-full bg-muted text-xs border">+{g.steps.length - 3}</span>
                    )}
                  </div>
                  <Button asChild>
                    <Link to={`/guide/${g.slug}`}>Open guide</Link>
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>
    </div>
  );
}
