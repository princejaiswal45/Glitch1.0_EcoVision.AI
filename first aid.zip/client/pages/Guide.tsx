import { useParams, Link } from "react-router-dom";
import { getGuide } from "@/data/injuries";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";

export default function Guide() {
  const { slug } = useParams();
  const guide = slug ? getGuide(slug) : undefined;

  if (!guide) {
    return (
      <div className="mx-auto max-w-3xl">
        <h1 className="text-2xl font-bold">Guide not found</h1>
        <p className="mt-2 text-muted-foreground">Please return to the homepage to see all available first-aid guides.</p>
        <Button asChild className="mt-4"><Link to="/">Back to Home</Link></Button>
      </div>
    );
  }

  return (
    <article className="mx-auto max-w-3xl">
      <Link to="/" className="text-sm text-primary hover:underline">← All guides</Link>
      <h1 className="mt-2 text-3xl md:text-4xl font-extrabold tracking-tight">{guide.title}</h1>
      {guide.urgentNote && (
        <div className="mt-4 rounded-xl border border-amber-300 bg-amber-50/60 p-4 text-amber-900">
          <strong className="block">Urgent</strong>
          <p className="text-sm mt-1">{guide.urgentNote}</p>
        </div>
      )}
      <p className="mt-3 text-muted-foreground">{guide.summary}</p>

      <Separator className="my-6" />

      <ol className="space-y-3">
        {guide.steps.map((s, i) => (
          <li key={s.id} className="flex items-start gap-3 rounded-xl border bg-card p-4">
            <span className="mt-0.5 inline-flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary text-primary-foreground text-xs font-bold">{i + 1}</span>
            <div>
              <p className="leading-relaxed">{s.text}</p>
              {s.caution && (
                <Badge variant="destructive" className="mt-2">Caution</Badge>
              )}
            </div>
          </li>
        ))}
      </ol>

      <div className="mt-8 rounded-xl bg-emerald-600 text-white p-4">
        <h2 className="font-semibold">When to call emergency services</h2>
        <p className="text-sm opacity-95 mt-1">If the situation worsens, the person is unresponsive, or you are unsure, call local emergency services immediately.</p>
        <Button asChild size="lg" className="mt-3 bg-white text-emerald-700 hover:bg-white/90">
          <a href="tel:">Call emergency services</a>
        </Button>
      </div>
    </article>
  );
}
