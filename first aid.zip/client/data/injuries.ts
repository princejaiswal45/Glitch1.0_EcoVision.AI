export type Step = { id: string; text: string; caution?: boolean };
export type InjuryGuide = {
  slug: string;
  title: string;
  summary: string;
  steps: Step[];
  urgentNote?: string;
};

export const INJURY_GUIDES: InjuryGuide[] = [
  {
    slug: "bleeding",
    title: "Severe Bleeding",
    summary:
      "Control heavy bleeding quickly to prevent shock. Apply firm pressure and keep the person calm.",
    urgentNote: "If bleeding is spurting or you see signs of shock, call emergency services immediately.",
    steps: [
      { id: "b1", text: "Wash or sanitize your hands if possible." },
      { id: "b2", text: "Apply firm, direct pressure with a clean cloth or bandage.", caution: true },
      { id: "b3", text: "If blood soaks through, add more cloths—do not remove the first layer.", caution: true },
      { id: "b4", text: "Elevate the bleeding area above the heart if it doesn't cause more pain." },
      { id: "b5", text: "Once bleeding slows, wrap snugly with a bandage without cutting off circulation." },
      { id: "b6", text: "Monitor for signs of shock: pale/clammy skin, rapid pulse, confusion. Keep warm." },
    ],
  },
  {
    slug: "cuts",
    title: "Cuts & Lacerations",
    summary:
      "Clean and protect cuts to reduce infection. Seek help for deep or jagged wounds.",
    steps: [
      { id: "c1", text: "Rinse the cut under clean running water for at least 30 seconds." },
      { id: "c2", text: "Gently clean around the wound with soap; avoid getting soap deep in the cut." },
      { id: "c3", text: "Control minor bleeding with gentle, direct pressure." },
      { id: "c4", text: "Apply an antibiotic ointment if available and cover with a sterile dressing." },
      { id: "c5", text: "Change the dressing daily or if wet/dirty. Watch for redness, swelling, or pus." },
    ],
  },
  {
    slug: "burns",
    title: "Burns (Thermal)",
    summary:
      "Cool the burn, protect the skin, and avoid breaking blisters.",
    urgentNote: "For large, deep, electrical, or chemical burns, call emergency services immediately.",
    steps: [
      { id: "bu1", text: "Stop the burning: remove the person from the heat source safely." },
      { id: "bu2", text: "Cool the burn with cool (not ice) running water for 10–20 minutes.", caution: true },
      { id: "bu3", text: "Remove rings, watches, or tight clothing before swelling starts." },
      { id: "bu4", text: "Cover loosely with sterile, non-stick dressing or clean cloth." },
      { id: "bu5", text: "Do not pop blisters or apply butter/creams that trap heat.", caution: true },
    ],
  },
  {
    slug: "fractures",
    title: "Fractures & Sprains",
    summary:
      "Immobilize the area and reduce swelling. Do not straighten a deformed limb.",
    steps: [
      { id: "f1", text: "Stop any bleeding with gentle pressure around the wound (not directly on bone).", caution: true },
      { id: "f2", text: "Immobilize: use a splint or padded board to keep joints above and below still." },
      { id: "f3", text: "Apply a cold pack wrapped in cloth for 15–20 minutes to reduce swelling." },
      { id: "f4", text: "Elevate if possible and safe. Avoid weight-bearing on injured limb." },
      { id: "f5", text: "Seek medical evaluation, especially with deformity, severe pain, or loss of function." },
    ],
  },
  {
    slug: "choking",
    title: "Choking (Adult/Child)",
    summary:
      "If the person cannot speak or cough, act quickly with back blows and abdominal thrusts.",
    urgentNote: "If alone, call emergency services on speaker while providing care.",
    steps: [
      { id: "ch1", text: "Ask: 'Are you choking?' If unable to speak/cough, continue." },
      { id: "ch2", text: "Give 5 sharp back blows between shoulder blades." },
      { id: "ch3", text: "Then give 5 abdominal thrusts (Heimlich): inward and upward above the navel.", caution: true },
      { id: "ch4", text: "Alternate 5 back blows and 5 thrusts until the object is expelled or help arrives." },
      { id: "ch5", text: "If the person becomes unresponsive, begin CPR and check airway for visible objects." },
    ],
  },
];

export const getGuide = (slug: string) => INJURY_GUIDES.find((g) => g.slug === slug);
